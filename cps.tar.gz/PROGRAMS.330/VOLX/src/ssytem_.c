ssytem_(str,cnt)
char *str;
int cnt;
{
	return((int)system(str));
}
