static char *gsac_version ="GSAC - Computer Programs in Seismology [V1.1.61 30 OCT 2022]\n       Copyright 2004-2022 R. B. Herrmann";

