#include	<stdio.h>
#include        "gsac.h"
#include	"gsac_version.h"


void gsac_set_param_v(int ncmd, char **cmdstr)
{
}

void gsac_exec_v(void)
{
	printf("%s\n",gsac_version);

}
